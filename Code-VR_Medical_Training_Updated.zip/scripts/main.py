# Main Script for VR Medical Training System
from modules.vr_environment import VREnvironment
from modules.haptic_feedback import HapticFeedback
from modules.performance_tracking import PerformanceTracker
from modules.adaptive_learning import AdaptiveLearning

if __name__ == "__main__":
    print("Initializing VR Medical Training System...")

    # VR Environment
    env = VREnvironment()
    env.load_scene("Advanced Medical Training Simulation")
    env.render_scene()

    # Haptic Feedback
    haptic = HapticFeedback()
    force = haptic.compute_force(displacement=0.02, velocity=0.03)
    print(f"Updated Computed Haptic Force: {force}")

    # Performance Tracking
    tracker = PerformanceTracker()
    tracker.start_tracking()
    tracker.stop_tracking()

    # Adaptive Learning
    adaptive = AdaptiveLearning()
    adjustment = adaptive.adjust_difficulty(current_performance=0.75, target_performance=0.95)
    print(f"Updated Difficulty Adjustment: {adjustment}")
