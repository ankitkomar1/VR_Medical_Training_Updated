# Performance Tracking System Module
import time

class PerformanceTracker:
    def __init__(self):
        self.start_time = None
        self.end_time = None

    def start_tracking(self):
        self.start_time = time.time()
        print("Performance tracking started...")

    def stop_tracking(self):
        self.end_time = time.time()
        elapsed_time = self.end_time - self.start_time
        print(f"Performance tracking stopped. Elapsed Time: {elapsed_time:.2f} seconds")
        return elapsed_time

if __name__ == "__main__":
    tracker = PerformanceTracker()
    tracker.start_tracking()
    time.sleep(3)  # Simulating a longer task
    elapsed = tracker.stop_tracking()
